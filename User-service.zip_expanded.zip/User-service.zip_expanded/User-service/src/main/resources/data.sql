insert into user(user_id, username, password, address, phone) values(1001L,'vamsi','vamsi333','Badvel',8919134794L);
insert into user(user_id, username, password, address, phone) values(1002L,'thanuja','thanu333','Badvel',8918134794L);
insert into user(user_id, username, password, address, phone) values(1003L,'venkatesh','venkatesh333','Badvel',9818134794L);
insert into user(user_id, username, password, address, phone) values(1004L,'sudha','sudha333','Badvel',9616134794L);
insert into user(user_id, username, password, address, phone) values(1005L,'swetha','swetha333','Badvel',8913434794L);